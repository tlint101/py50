# py50

py50 is used to generate dose-response curves. The repository can be installed using the following:

```
pip install py50
```

Additional documentation and tutorials can be found at the following repository:
https://github.com/tlint101/py50